package com.simplepicpay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimplepicpayApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimplepicpayApplication.class, args);
	}

}
