package com.simplepicpay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimplepicpayApplicationTests {

	@Test
	void contextLoads() {
	}

}
